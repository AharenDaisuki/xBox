package cmd;

import java.util.ArrayList;
import data.*;
import java.text.SimpleDateFormat;  
import java.util.Date;  

public class RequestBoxCommand extends Undoable{
    private static Client thisClient;

    @Override
    public void redo(){
        addUndo(this);
        
    }
    @Override
    public void undo(){

        addRedo(this);
    }

    public void execute(String[] cmdLine){
        /*
        cmdLine[0] 
        request,box/bag,number,date
        */
        thisClient=clientSearcher.searchByClientEmail(cmdLine[0]);

        Rentable rentable=  RentableAllocator.borrowRentable(thisClient,cmdLine[1],cmdLine[3].toDate());
        rentableManager.lendOutRentable(rentable);
        RecordManager.insert(thisClient,rentable,cmdLine[3].parse()); 
        
        addUndo(null);
        clearList();
    };
}
