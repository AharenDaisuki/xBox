package cmd;
import java.lang.*;
import data.*;
public class AdminCommand extends UserCommand{

    @Override
    public String login
    public void confirmPay(){

    }
    public void rejectPay(){

    }
    public void confirmReturn(){

    }
    public void rejectReturn(){
        
    }
}
